import React, { useState, useEffect } from "react";
import img from "../img/nasa.jpg";
export default function PhotosPage() {
  const [photos, setPhotos] = useState([]);
  const today = new Date();
  const [infoSelected, toggleInfo] = useState(0);
  const [date,searchD] = useState(today
    .getFullYear()
    .toString()
    .concat(
      "-" + today.getMonth() + 1 + "-",
      today.getDate() - 1
    ))

  useEffect(() => {
    const fetcher = async () => {
      await fetch(
        `https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?earth_date=${date}&api_key=H8l38zDAFsfnHR1mUIc8nX4zeYI77Ml11bdXrJHm`
      )
        .then((resp) => {
          return resp.json();
        })
        .then((data) => {
          setPhotos(data.photos);
        })
        .catch((e) => {
          setPhotos(null);
        });
    };
    fetcher();
  }, [date]);


  const toggleI = (e) =>{
    e.preventDefault();
toggleInfo((Cc)=>{
  Cc!==e.target.className ? (Cc = e.target.className) : (Cc = 0);
  return Cc;
});
}

  const toggle = (e) => {
    if (e.target.value === "Like!") e.target.value = "Unlike";
    else e.target.value = "Like!";
  };

  

  return (
    <div>
      <div id="fixedMenuBar">
        <div id="container">
          <span>Welcome to Rover in Mars!</span>
          <input type="button" id="SearchBtn" value="Search" onClick={()=>{searchD(document.querySelector('#searchBar').value)}} />
          <input type="text" id="searchBar" placeholder="Search by date (YYYY-MM-DD)" />
        </div>
        <p>Here are pictures took on {date} by the curiosity rover on mars:</p>
      </div>
      <div id="cells">
        {photos != null && photos.length!=0
          ? photos.map((a) => (
              <div className="images" key={a.id}>
              <div id="user">
                
                <img src={img} alt="Curiosity" className="curious" />
                <span id="username">    Curiosity2011</span>
              </div>
                <br />  {" "}
                <img src={a.img_src} className="img" alt="Rover in mars!" />{" "}<br/>
               
                <input className="like" type="button" onClick={toggle} value="Like!" />{" "}<br/><br/>
               <a href="#" onClick={toggleI} className={a.id}> Sol: {a.sol} </a>{Number(infoSelected) === a.id? 
               
               <a href="#" onClick={toggleI} className={a.id}><br/>{"Camera full name: "+a.camera.full_name}<br/>{"Rover name: "+a.rover.name}<br/>{"Landing date of rover: "+a.rover.landing_date}<br/>{" Launch date of rover: "+a.rover.launch_date}</a> : <a href="#" onClick={toggleI} className={a.id}>{''.concat('Camera name: '+a.camera.name+'...')}</a>}<br/>
                            
                Date: {a.earth_date}
              </div>
            ))
          : <h3 id="nothingToShow">Nothing to show</h3>}
      </div>
    </div>
  );
}
