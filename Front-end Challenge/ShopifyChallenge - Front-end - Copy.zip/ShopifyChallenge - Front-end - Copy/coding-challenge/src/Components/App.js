
import '../App.css';
import PhotosPage from './PhotosPage';
function App() {
  return ( 
    <PhotosPage></PhotosPage>
  );
}

export default App;
