
const express = require('express')
const app =express();
const fs = require('fs');
const fsPromises = fs.promises;
const path = require('path');
const PORT = 8765;
const thePath = path.join(__dirname,'public', 'addItem.html');

const OPTIONS = {
    "index": "shop.html",
    "setHeaders": (res, path, stat) => {
        res.set('myHeader', 'Charles');
        res.set('x-timestamp', Date.now())
    },
 
}

app.use(express.static('public', OPTIONS));
//serving shop.html as my default page

app.use(express.urlencoded({
    'extended': true
}));
//making sure that middle ware can use forms

app.use(express.json());

//saying middleware can use json
app.route('/sendInventory').post((req,res)=>{
    let idArray;
    let invArray;
let number1 = isNaN(+req.body.input1)?0:+req.body.input1;
let number2 = isNaN(+req.body.input2)?0:+req.body.input2;
let name = req.body.input3.trim()==""?"unknown":req.body.input3;
fsPromises.readFile('./inventory.json').then((resp)=>{
    
    invArray = JSON.parse(resp);
   if(invArray.length==0)
   throw "array is empty";
    idArray = invArray.map((a)=>a.id);
  

    let maxId = Math.max(...idArray)+1;
    let newItem = {
        id:maxId,
        name:name,
        cost: number1,
        amount: number2,
    };
    invArray.push(newItem);
    fs.writeFile('./inventory.json',JSON.stringify(invArray,null,2),function(err){if(err)throw err});
    }).catch(e=>{
        let newItem = {
            id:1,
            name:name,
            cost: number1,
            amount: number2,
        };
        invArray = [newItem];
        fs.writeFile('./inventory.json',JSON.stringify(invArray,null,2),function(err){if(err)throw err});
        
    });
    res.sendFile(thePath);
});

app.route('/getItems/:filter?').get((req,res)=>{
     
        fsPromises.readFile('./inventory.json').then((resp)=>{
     let  invArray = JSON.parse(resp);
            let newArray =[]
    
            if(req.params.filter=='out') 
             newArray = invArray.map(a=>{if(a.amount==0)return a;})
    
             else if(req.params.filter=="stock"){
             newArray = invArray.map(a=>{if(a.amount!=0)return a;})}
             else
             newArray=invArray;
            res.send(newArray);
        }).catch(e=>{
            res.send("Nothing to show")
        });

})



app.route('/modifyItems').put((req,res)=>{
    fsPromises.readFile('./inventory.json').then((resp)=>{


        let invArray = JSON.parse(resp);
        let name = req.body.name==""?"unknown":req.body.name;
        let newArray= invArray.map(a=>{if(a.id==req.body.id){
let newItem = {
id:req.body.id,
name:name,
cost:+req.body.cost,
amount:+req.body.units
}
            return newItem

        }else return a});
      
        fs.writeFile('./inventory.json',JSON.stringify(newArray,null,2),function(err){
            if(err) throw err
        });}
    
    );

})
app.route('/delete/:del').delete((req,res)=>{
    fsPromises.readFile('./inventory.json').then((resp)=>{
let jsonArray = JSON.parse(resp);
let changed=false;
let newArray = jsonArray.map(a=>{
   if(a.id==req.params.del){
changed=true;
return null;
   } 
   else return a
});
newArray.splice(newArray.indexOf(null),1)
fs.writeFile('./inventory.json',JSON.stringify(newArray,null,2),function(err){
    if(err) throw err
});
    })

});


app.listen(PORT, ()=>{
console.log(`Listening on Port: ${PORT}`)
});


