const $$ = (selector) => document.querySelector(selector);
let selectValue = document.querySelector('select')
let opt = selectValue.options[selectValue.selectedIndex].id;
const createElement = (newElement) => document.createElement(newElement);
const appendElement = (parent, child) => {
  parent.appendChild(child);
};

async function fetchData() {
  return (await fetch("/getItems")).json();
}
window.addEventListener("load", async () => {
  let items = [];
  try{
  items = await fetchData();

  items.forEach((element) => {
 

    let thisItem = createElement("p");
    thisItem.innerHTML = `${element.id} ${element.name} ${element.amount} ${element.cost}`;
   
    thisItem.id = element.id;
    appendElement($$("#displayDiv"), thisItem);

 let deleteButton = createElement("button");
    deleteButton.id = element.id+"delete"
    deleteButton.innerHTML="delete product"
    appendElement(thisItem,deleteButton);    



    let buttonModify = createElement("button");
    buttonModify.id = element.id + "modify";

    
    appendElement(thisItem, buttonModify);
    buttonModify.innerHTML="modify product";

    addFields(thisItem,element.id,"cost","name","units");
    
    buttonModify.addEventListener("click", () => {

const costE = document.querySelector(`#cost${element.id}`).value;
const name = document.querySelector(`#name${element.id}`).value;
const units = document.querySelector(`#units${element.id}`).value;



    fetch('/modifyItems',{method:"put", headers:{"content-type":"application/json"}, body:JSON.stringify({
        id:element.id,
    cost:costE,
    name:name,
    units:units
    })}).then(window.location.reload())

   
    });
  
deleteButton.addEventListener("click",()=>{
fetch(`/delete/${element.id}`,{method:"delete"}).then(window.location.reload());
})

});
}catch(e){
  console.log(e);
document.querySelector('body').innerHTML+="nothing to show"
}});

$$("#filterBtn").addEventListener("click",()=>{

fetch(`/getItems/${selectValue.options[selectValue.selectedIndex].id}`).then((res)=>
res.json()
).then(
(response=>{


  items = response
  items = items.filter(a=>a!=null);
  $$("#displayDiv").innerHTML="";
  items.forEach((element) => {
 

    let thisItem = createElement("p");
    thisItem.innerHTML = `${element.id} ${element.name} ${element.amount} ${element.cost}`;
   
    thisItem.id = element.id;
    appendElement($$("#displayDiv"), thisItem);

 let deleteButton = createElement("button");
    deleteButton.id = element.id+"delete"
    deleteButton.innerHTML="delete product"
    appendElement(thisItem,deleteButton);    



    let buttonModify = createElement("button");
    buttonModify.id = element.id + "modify";

    
    appendElement(thisItem, buttonModify);
    buttonModify.innerHTML="modify product";

    addFields(thisItem,element.id,"cost","name","units");
    
    buttonModify.addEventListener("click", () => {

const costE = document.querySelector(`#cost${element.id}`).value;
const name = document.querySelector(`#name${element.id}`).value;
const units = document.querySelector(`#units${element.id}`).value;

    fetch('/modifyItems',{method:"put", headers:{"content-type":"application/json"}, body:JSON.stringify({
        id:element.id,
    cost:costE,
    name:name,
    units:units
    })}).then(window.location.reload())
   
    });
  
deleteButton.addEventListener("click",()=>{
fetch(`/delete/${element.id}`,{method:"delete"}).then(window.location.reload());
})

});
  

}))})

function addFields (thisItem,elementid,...args){
args.forEach(a=>{
  let currentField = createElement("input");
currentField.type = 'text';

currentField.id = a+elementid;

currentField.placeholder="Enter the "+a;
appendElement(thisItem,currentField);
});

};